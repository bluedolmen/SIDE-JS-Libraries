<root>
<jsp:include page="fileUtil.js"/>

logger.log('validation3RO.js');

logger.log('Target initialization');
var target = '6 - 4RO';

Util.move(bpm_package, target, 'JobOffer:JobRequisition_history');

</root>
