<root>
<jsp:include page="fileUtil.js"/>

logger.log('validation4RO.js');

logger.log('Target initialization');
var target = '7 - 5RO';

Util.move(bpm_package, target, 'JobOffer:JobRequisition_history');

</root>
