<root>
<jsp:include page="fileUtil.js"/>

logger.log('oK.js');

logger.log('Target initialization');
var target = '8 - Approved';

Util.move(bpm_package, target);

</root>
